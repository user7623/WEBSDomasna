package webproject.filmreview.Models;

public enum Genres 
{
    COMEDY, HORROR, ACTION, DOCUMENTARY, DRAMA, THRILLER, BIOGRAPHY, ROMANCE;
}